@extends($activeTemplate.'layouts.master')
@section('content')
    <div id="appCapsule">
        <div class="section mt-5 text-center">
            <h1>@lang('Password')</h1>
            <h4>Update account @lang('Password') ..</h4>
        </div>
        <section class="cmn-section">
	        <div class="container">
                <div class="card">
                    <div class="card-body">
                        <form action="" method="post">
                            @csrf
                            <div class="form-group basic mt-1">
                                <label class="label">@lang('Current Password')</label>
                                <input type="password" class="form-control form-control" name="current_password" required autocomplete="current-password">
                            </div>
                            <div class="form-group basic mt-1">
                                <label class="label">@lang('Password')</label>
                                <input type="password" class="form-control form-control" name="password" required autocomplete="current-password">
                                @if($general->secure_password)
                                    <div class="input-popup">
                                      <p class="error lower">@lang('1 small letter minimum')</p>
                                      <p class="error capital">@lang('1 capital letter minimum')</p>
                                      <p class="error number">@lang('1 number minimum')</p>
                                      <p class="error special">@lang('1 special character minimum')</p>
                                      <p class="error minimum">@lang('6 character password')</p>
                                    </div>
                                @endif
                            </div>
                            <div class="form-group basic mt-1">
                                <label class="label">@lang('Confirm Password')</label>
                                <input type="password" class="form-control form-control" name="password_confirmation" required autocomplete="current-password">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn--base text-white w-100">@lang('Submit')</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <div class="py-4"></div>
    </div>

@endsection
@if($general->secure_password)
    @push('script-lib')
        <script src="{{ asset('assets/global/js/secure_password.js') }}"></script>
    @endpush
@endif
